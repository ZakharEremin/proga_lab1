﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string v1 = textBox1.Text;
            string t = textBox2.Text;
            string L = textBox3.Text;
            double v1_1 = Convert.ToDouble(v1);
            double t_1 = Convert.ToDouble(t);
            double L_1 = Convert.ToDouble(L);
            double v2 = (L_1 - v1_1 * t_1) / t_1;
            textBox4.Text = v2.ToString();
        }
    }
}
